<?php

require_once 'vendor/autoload.php';

$app = require_once 'bootstrap/app.php';
$app->make('Illuminate\Contracts\Console\Kernel')->bootstrap();

echo "🔍 Verdex Backend Deployment Check\n";
echo "==================================\n\n";

$checks = [
    'PHP Version' => function() {
        $version = PHP_VERSION;
        $required = '8.2.0';
        if (version_compare($version, $required, '>=')) {
            echo "✅ PHP Version: {$version} (>= {$required})\n";
            return true;
        } else {
            echo "❌ PHP Version: {$version} (required >= {$required})\n";
            return false;
        }
    },
    
    'Composer Dependencies' => function() {
        if (file_exists('vendor/autoload.php')) {
            echo "✅ Composer dependencies installed\n";
            return true;
        } else {
            echo "❌ Composer dependencies not found\n";
            return false;
        }
    },
    
    'Environment File' => function() {
        if (file_exists('.env')) {
            echo "✅ .env file exists\n";
            return true;
        } else {
            echo "❌ .env file not found\n";
            return false;
        }
    },
    
    'App Key' => function() {
        $key = env('APP_KEY');
        if ($key && $key !== 'base64:') {
            echo "✅ Application key is set\n";
            return true;
        } else {
            echo "❌ Application key not set\n";
            return false;
        }
    },
    
    'Storage Directory' => function() {
        $paths = [
            'storage/app/public',
            'storage/framework/cache',
            'storage/framework/sessions',
            'storage/framework/views',
            'storage/logs'
        ];
        
        $allExist = true;
        foreach ($paths as $path) {
            if (!is_dir($path)) {
                echo "❌ Directory missing: {$path}\n";
                $allExist = false;
            }
        }
        
        if ($allExist) {
            echo "✅ All storage directories exist\n";
        }
        
        return $allExist;
    },
    
    'Database Connection' => function() {
        try {
            \DB::connection()->getPdo();
            echo "✅ Database connection successful\n";
            return true;
        } catch (\Exception $e) {
            echo "❌ Database connection failed: " . $e->getMessage() . "\n";
            return false;
        }
    },
    
    'Required Extensions' => function() {
        $required = [
            'bcmath', 'ctype', 'fileinfo', 'json', 'mbstring', 
            'openssl', 'pdo', 'tokenizer', 'xml', 'curl', 'gd'
        ];
        
        $missing = [];
        foreach ($required as $ext) {
            if (!extension_loaded($ext)) {
                $missing[] = $ext;
            }
        }
        
        if (empty($missing)) {
            echo "✅ All required PHP extensions loaded\n";
            return true;
        } else {
            echo "❌ Missing extensions: " . implode(', ', $missing) . "\n";
            return false;
        }
    }
];

$passed = 0;
$total = count($checks);

foreach ($checks as $name => $check) {
    echo "\n🔍 Checking {$name}...\n";
    if ($check()) {
        $passed++;
    }
}

echo "\n" . str_repeat("=", 50) . "\n";
echo "📊 Deployment Check Results\n";
echo "Passed: {$passed}/{$total}\n";

if ($passed === $total) {
    echo "🎉 All checks passed! Ready for deployment.\n";
    exit(0);
} else {
    echo "⚠️  Some checks failed. Please fix issues before deploying.\n";
    exit(1);
} 